# start.kubermatic.io

These are the generated secret keys which should not be committed at your repository!
You should set them for your GitHub Secrets, see the [README](README.md#preparation) steps.

## Age keys

* Private key: `AGE-SECRET-KEY-1C7398CLA76DYANETD64P5XQG8063QS9K9A9WCPUX7WLTYH5Q383Q32GD2D`
* Public key: `age100v366ra794gzdeqy708sct8aa3f4ln6a5vgjffcs6f26mh04u0q07tqwu`

## Secrets

* Dex static user password: `cp<i- jCzim}n!bQ`


## Terraform State S3 Backend

* Bucket name: `tf-state-kkp-x_1sux0dwomcxu3w`

